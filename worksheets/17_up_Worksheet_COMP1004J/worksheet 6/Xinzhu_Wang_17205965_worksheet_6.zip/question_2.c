#include <stdio.h>
#include <stdlib.h>

int main()
{
    int myage = 17;
    printf("My age is %d",myage);
    getchar();
    return 0;
}

#include <stdio.h>
#include <stdlib.h>

int main()
{
    char myname[] = "Mitchell";
    printf("My name is %s",myname);
    getchar();
    return 0;
}
